import { useCallback, useState } from "react"
import { veiculoService } from "../services/veiculoService"
import { servicoService } from "../services/servicoService"

export function useBuscarServico() {
  const veiculoApi = veiculoService()
  const servicoApi = servicoService()
  const [servicos, setServicos] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  const buscarPorPlaca = useCallback(async (placa) => {
    if (!placa || placa.length !== 7) {
      setError("Placa obrigatória")
      setServicos([])
      return []
    }

    setLoading(true)
    setError("")

    try {
      const respostaVeiculo = await veiculoApi.buscarPorPlaca(placa)
      const veiculo = respostaVeiculo?.data ?? respostaVeiculo

      if (!veiculo?.id) {
        setServicos([])
        setError("Veículo não encontrado")
        return []
      }

      const respostaServicos = await servicoApi.listarPorVeiculo(veiculo.id)
      const listaServicos = respostaServicos?.data ?? respostaServicos ?? []

      setServicos(listaServicos)
      return listaServicos
    } catch (err) {
      setServicos([])
      setError(err?.message || "Erro ao buscar serviço")
      return []
    } finally {
      setLoading(false)
    }
  }, [servicoApi, veiculoApi])

  return { servicos, loading, error, buscarPorPlaca }
}

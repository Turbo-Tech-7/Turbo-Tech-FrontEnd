docker build -t turbotech .

docker run -dp 5173:5173 -it turbotech